package com.yash.yits.form;

public class IssueTypeForm{

	private int issueId;

	private String issueType;

	public IssueTypeForm() {
	}

	public int getIssueId() {
		return this.issueId;
	}

	public void setIssueId(int issueId) {
		this.issueId = issueId;
	}

	public String getIssueType() {
		return this.issueType;
	}

	public void setIssueType(String issueType) {
		this.issueType = issueType;
	}
}