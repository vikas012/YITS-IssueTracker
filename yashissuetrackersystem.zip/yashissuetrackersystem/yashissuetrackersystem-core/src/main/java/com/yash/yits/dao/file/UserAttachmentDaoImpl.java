package com.yash.yits.dao.file;

import com.yash.yits.dao.UserAttachmentDao;

public class UserAttachmentDaoImpl implements UserAttachmentDao{

}
