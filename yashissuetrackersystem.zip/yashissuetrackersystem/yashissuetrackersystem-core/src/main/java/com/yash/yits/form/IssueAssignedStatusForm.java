package com.yash.yits.form;

public class IssueAssignedStatusForm{

	private int issueAssignmentStatusId;
	private String issueAssignmentStatus;
	
	public int getIssueAssignmentStatusId() {
		return issueAssignmentStatusId;
	}
	public void setIssueAssignmentStatusId(int issueAssignmentStatusId) {
		this.issueAssignmentStatusId = issueAssignmentStatusId;
	}
	public String getIssueAssignmentStatus() {
		return issueAssignmentStatus;
	}
	public void setIssueAssignmentStatus(String issueAssignmentStatus) {
		this.issueAssignmentStatus = issueAssignmentStatus;
	}
}