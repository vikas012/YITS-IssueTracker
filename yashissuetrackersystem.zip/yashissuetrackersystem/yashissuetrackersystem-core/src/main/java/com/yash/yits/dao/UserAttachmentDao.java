package com.yash.yits.dao;

public interface UserAttachmentDao {

}
