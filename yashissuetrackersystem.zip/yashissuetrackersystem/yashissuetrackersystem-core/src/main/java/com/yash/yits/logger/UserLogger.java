package com.yash.yits.logger;

public class UserLogger {

}
