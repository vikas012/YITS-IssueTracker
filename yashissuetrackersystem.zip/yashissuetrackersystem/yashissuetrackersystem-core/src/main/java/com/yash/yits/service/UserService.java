package com.yash.yits.service;

public interface UserService {

}
