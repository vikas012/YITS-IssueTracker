package com.yash.yits.dao.hibernate;

import com.yash.yits.dao.UserDao;

public class UserDaoImpl implements UserDao{

}
