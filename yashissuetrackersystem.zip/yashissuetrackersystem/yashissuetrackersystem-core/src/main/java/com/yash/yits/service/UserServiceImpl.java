package com.yash.yits.service;

public class UserServiceImpl implements UserService{

}
