package com.yash.yits.form;

public class IssuePriorityForm{
	
	private int issuePriorityId;

	private String issuePriorityType;

	public int getIssuePriorityId() {
		return issuePriorityId;
	}

	public void setIssuePriorityId(int issuePriorityId) {
		this.issuePriorityId = issuePriorityId;
	}

	public String getIssuePriorityType() {
		return issuePriorityType;
	}

	public void setIssuePriorityType(String issuePriorityType) {
		this.issuePriorityType = issuePriorityType;
	}
}