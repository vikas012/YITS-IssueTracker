package com.yash.yits.mapper;

public class UserMapper {

}
